from rest_framework import generics, permissions, status
from rest_framework.response import Response
from django.urls import reverse
from .models import Post, Comment
from .serializers import PostSerializer, CommentSerializer
from django.shortcuts import get_object_or_404
from rest_framework.pagination import PageNumberPagination
class PostList(generics.ListCreateAPIView):
    queryset = Post.objects.all()
    pagination_class = PageNumberPagination  # Add pagination class
    serializer_class = PostSerializer
    #IsAuthenticatedOrReadOnly hedhi bsh nekhdmou beha el condition eli ken el authentifie ymodifiw
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    #function hedhi bsh lel NON-AUTH juste el published yrawha
    def get_queryset(self):
        if self.request.user.is_authenticated:
            return Post.objects.all()
        return Post.objects.filter(status='published')

    def perform_create(self, serializer):
        post = serializer.save(author=self.request.user)
        # Redirect to the post detail after creation
        response = Response(serializer.data, status=status.HTTP_201_CREATED)
        response['Location'] = reverse('post_detail', kwargs={'pk': post.pk})
        return response

class PostDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_object(self):
        post = super().get_object()
        if post.status != 'published' and not self.request.user.is_authenticated:
            self.permission_denied(self.request, message="Not found.")
        return post
    def perform_destroy(self, instance):
        if self.request.user != instance.author:
            self.permission_denied(self.request, message="You do not have permission to delete this post.")
        instance.delete()

class PostCreate(generics.CreateAPIView):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        post = serializer.save(author=self.request.user)
        # Redirect to the post detail after creation
        response = Response(serializer.data, status=status.HTTP_201_CREATED)
        return response

class CommentList(generics.ListCreateAPIView):
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        post_pk = self.kwargs['post_pk']
        return Comment.objects.filter(post_id=post_pk)

    def perform_create(self, serializer):
        post_pk = self.kwargs['post_pk']
        post = get_object_or_404(Post, pk=post_pk)
        comment = serializer.save(author=self.request.user, post=post)
        # Redirect to the post detail after comment creation
        response = Response(serializer.data, status=status.HTTP_201_CREATED)
        return response

class CommentDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_object(self):
        comment = super().get_object()
        
        return comment
    def perform_destroy(self, instance):
        if self.request.user != instance.author:
            self.permission_denied(self.request, message="You do not have permission to delete this coment.")
        instance.delete()
