from django.urls import path
from .views import PostList, PostDetail, PostCreate, CommentList, CommentDetail

urlpatterns = [
    path('', PostList.as_view(), name='home'),
    path('posts/', PostList.as_view(), name='post_list'),
    path('posts/<int:pk>/', PostDetail.as_view(), name='post_detail'),
    path('posts/new/', PostCreate.as_view(), name='post_create'),
    path('posts/<int:post_pk>/comments/', CommentList.as_view(), name='comment_list'),
    path('comments/<int:pk>/', CommentDetail.as_view(), name='comment_detail'),
]
